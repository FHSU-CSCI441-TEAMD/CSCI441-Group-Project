Group Name: Group D
Project Name: Service (Ticketing) Management System
Group Members: Husein Abdulraheem, Chan Nirak Choun, Jakob Dunlap, Gregory Hall

Group GitHub Repository:
https://github.com/FHSU-CSCI441-TEAMD/CSCI441-Group-Project

Application Website:
https://quicktix-r1fv.onrender.com/

1. Project Overview

The Service (Ticketing) Management System is a web-based application designed to streamline user support through ticket creation, assignment, and resolution. The system supports three user roles: Customer, Agent, and Admin, each with different privileges in the platform.

2. How to Run / Access the Application

Since the project is deployed online, no local installation is required.

Steps to Access the System

Open a web browser (Chrome, Firefox, Edge, etc.).

Go to the following URL:
https://quicktix-r1fv.onrender.com/

Log in using one of the authenticated user accounts listed below.

3. Login Credentials

Customer Account
Email: janedoe-smith@mail.com
Password: Janedoe@808
Role: Customer
Permissions: Create tickets, view ticket status, update personal info.

Agent Account
Email: csci441agent@proton.me
Password: agentpassword123
Role: Agent
Permissions: View assigned tickets, update ticket status, respond to users.

Admin Account
Email: ticketingcsci@gmail.com
Password: newpassword123
Role: Admin
Permissions: Reassign tickets, manage agents, oversee all tickets, administrative setup.

4. Folder Descriptions

Below is a brief description of each folder included in the archive:

presentation_slides/

Contains presentation materials for Demo #1 and Demo #2, including slides that summarize system features, design updates, and progress reports.

reports/

Contains Full Report #1, Full Report #2, and Full Report #3, which document:

System design
Functional requirements
Non-functional requirements
Architecture diagrams and workflow diagrams
Use case descriptions
Development progress and testing methodology

source_code/

Contains the full source code of the project, including:

Frontend (UI components, routing, styling, forms)
Backend (API routes, database models, authentication, business logic)

tests/

Contains automated test files, including:

Frontend unit tests
Backend unit tests
Integration tests covering major workflows throughout the system

5. Additional Notes

Ensure that your internet connection is active when accessing the hosted app.
If the Render deployment is slow to start, wait a few seconds; free-tier hosting may cause initial loading delay.
For full documentation, refer to files under the reports folder.