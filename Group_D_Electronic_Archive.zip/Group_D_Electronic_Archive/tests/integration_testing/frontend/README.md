<!-- written by: Gregory Hall -->
<!-- tested by: Gregory Hall -->
<!-- debugged by: Gregory Hall -->

---

# ✅ **README – Integration Tests**

_(Save as: `/integration_testing/README.md`)_

````markdown
# Integration Testing Documentation

This directory contains the **integration tests** for the QuickTix frontend application.  
Integration tests focus on verifying **multiple components working together**, including:

- State management (TicketsContext)
- Navigation (react-router-dom)
- User workflows (form submission, validation)

These tests simulate **real user behavior** as closely as possible within a browser-like environment.

---

## 🎯 Purpose of Integration Tests

Integration tests ensure that:

- Users can successfully log in, create tickets, and update their information.
- Multiple parts of the application work together as intended.
- Navigation and component interactions do not break after code changes.
- Mocked API calls behave as expected when the UI triggers them.

While unit tests validate individual pieces, **integration tests validate complete workflows**.

---

## 📁 Included Integration Tests

### 1. **CreateTicket.test.js**

Simulates the full "Create Ticket" workflow:

- Users fill out form fields.
- Validation is triggered.
- Mocked API calls simulate successful ticket creation.
- Navigation to `/home` is tested.

### 2. **Login.test.js**

Simulates user login:

- Email + password entry
- Successful login for Admin or Customer
- Correct redirect based on user role:
  - Admin → `/admin-reports`
  - Customer → `/home`
- Uses mocked context and mocked API responses.

### 3. **TicketUpdate.test.js**

Basic smoke test that:

- Renders the update page
- Ensures the "Edit Ticket" heading appears
- Confirms the app does not crash during load

The deeper logic of TicketUpdate is heavily dependent on backend fetch behavior, so the integration test ensures the UI loads without errors.

---

## 🔄 How Integration Tests Work

Integration tests use:

### **Mocked API calls**

All fetch/axios calls are mocked so tests do not hit a real backend.

### **Mocked TicketsContext**

A lightweight fake version of the context is used to simulate:

- currentUser
- createTicket()
- fetchTickets()
- setCurrentUser()

### **Mocked React Router**

- `useNavigate()` is mocked to verify redirects
- `MemoryRouter` simulates routing for UI tests

---

## 🚀 Running Integration Tests

```bash
npm test
```
````
