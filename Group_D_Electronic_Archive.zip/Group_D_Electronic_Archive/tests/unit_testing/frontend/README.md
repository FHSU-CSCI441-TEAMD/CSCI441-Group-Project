<!-- written by: Gregory Hall -->
<!-- tested by: Gregory Hall -->
<!-- debugged by: Gregory Hall -->

# Unit Testing Documentation

This directory contains the **unit tests** for the QuickTix frontend application.  
Unit tests focus on verifying **small, isolated pieces of logic** without involving
API calls, navigation, or global state whenever possible.

---

## 🎯 Purpose of Unit Tests

Unit tests in this project ensure that:

- Individual components render correctly.
- Helper functions behave as expected.
- Component logic works independently from the rest of the system.
- UI behavior does not break during refactoring.

Unit tests are designed to be **fast**, **predictable**, and **fully isolated**.

---

## 📁 Included Unit Tests

### 1. **makeTicketId.test.js**

Tests the `makeTicketId()` helper function:

- Generates a unique string ID.
- Follows the expected ticket ID format (`TIX-<timestamp>-<random>`).

### 2. **TicketsTable.test.js**

Validates isolated behavior of the TicketsTable component:

- Renders table rows correctly.
- Displays agent assignment properly.
- Navigates to the correct ticket page when a row is clicked.
- Runs using mocked navigation and mocked TicketsContext.

### 3. **Other Component-Level Unit Tests**

Some tests also verify basic rendering:

- Verifying a heading exists
- Confirming elements appear based on props

These tests ensure the UI responds correctly when given specific controlled inputs.

---

## 🚀 Running Unit Tests

From the project root:

```bash
cd frontend
npm test
```
